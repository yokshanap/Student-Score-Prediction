# The-Sparks-Foundation-Task-2

Author : Golanakonda Sai Kiran

TASK 2- Prediction using Unsupervised Machine Learning

GRIP@TSF - GRIPJULY21
